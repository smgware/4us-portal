<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;



class ProjectsController extends BaseController
{
    #[Route('/projects', name: 'index_projects')]
    public function index(): Response
    {


        return $this->render('projects/index.html.twig');

    }
}

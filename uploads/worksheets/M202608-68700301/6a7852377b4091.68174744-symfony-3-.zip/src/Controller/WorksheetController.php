<?php

namespace App\Controller;

use App\Entity\Worksheet;
use App\Entity\WorksheetAttachment;
use Dompdf\Dompdf;
use Dompdf\Options;
use App\Repository\MachineRepository;
use App\Repository\PartnerRepository;
use App\Repository\WorksheetAttachmentRepository;
use App\Repository\WorksheetRepository;
use App\Repository\WorksheetTypeRepository;
use App\Repository\UserRepository;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Attribute\Route;

class WorksheetController extends BaseController
{
    private const ITEMS_PER_PAGE = 20;
    private const ERROR_REPORT_TYPE_CODES = ['ERROR_REPORT', 'ERROR_REPORTING'];

    #[Route('/worksheets', name: 'index_worksheets')]
    public function index(WorksheetTypeRepository $worksheetTypeRepository): Response
    {
        return $this->render('worksheets/index.html.twig', [
            'worksheetTypes' => $worksheetTypeRepository->findBy([], ['title' => 'ASC']),
        ]);
    }


    #[Route('/worksheets/add', name: 'index_worksheets_add', methods: ['POST'])]
    public function index_worksheets_add(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetTypeRepository $worksheetTypeRepository,
    ): Response {
        $idRaw = $request->request->get('id', $request->request->get('worksheet_id', ''));

        if (!is_numeric($idRaw)) {
            $rentalIdRaw = $request->request->get('rental_id', '');
            $worksheetTypeCode = trim((string) $request->request->get('code_worksheet_type', ''));

            if (is_numeric($rentalIdRaw) && $worksheetTypeCode !== '') {
                $worksheetType = $worksheetTypeRepository->findOneBy(['code' => $worksheetTypeCode]);
                $worksheet = $worksheetType ? $worksheetRepository->findOneBy([
                    'machineRental' => (int) $rentalIdRaw,
                    'worksheetType' => $worksheetType,
                ]) : null;

                if ($worksheet) {
                    $idRaw = $worksheet->getId();
                }
            }
        }

        return $this->response(true, [
            'template' => 'worksheets/index_add.html.twig',
            'templateData' => [
                'id' => $idRaw
            ],
            'data' => [],
        ]);

    }


    #[Route('/worksheets/datacontent', name: 'index_worksheet_add_main', methods: ['POST'])]
    public function index_worksheet_add_main(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetTypeRepository $worksheetTypeRepository,
        WorksheetAttachmentRepository $worksheetAttachmentRepository,
        PartnerRepository $partnerRepository,
        MachineRepository $machineRepository,
    ): Response
    {
        $idRaw = $request->request->get('id', $request->request->get('worksheet_id', ''));
        $id = is_numeric($idRaw) ? (int) $idRaw : 0;

        $item = $id > 0 ? $worksheetRepository->find($id) : null;
        $isNew = $id <= 0;
        $isServiceOnly = $this->isGranted('ROLE_SERVICE')
            && !$this->isGranted('ROLE_MASTER')
            && !$this->isGranted('ROLE_PROJECTMANAGER');
        $worksheetTypes = $isServiceOnly
            ? $worksheetTypeRepository->findBy(['code' => self::ERROR_REPORT_TYPE_CODES], ['title' => 'ASC'])
            : $worksheetTypeRepository->findBy([], ['title' => 'ASC']);

        if ($isNew) {
            $defaultWorksheetType = $worksheetTypeRepository->findOneBy(['code' => 'ERROR_REPORT'])
                ?? $worksheetTypeRepository->findOneBy(['code' => 'ERROR_REPORTING'])
                ?? ($worksheetTypes[0] ?? null);

            if ($defaultWorksheetType === null) {
                return $this->response(false, [
                    'data' => ['error' => 'missing_worksheet_type'],
                ], 'json', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $item = (new Worksheet())
                ->setTitle('')
                ->setCode('')
                ->setWorksheetType($defaultWorksheetType)
                ->setData([])
                ->setStatus('1');
        } elseif (!$item || ($isServiceOnly && !in_array($item->getWorksheetType()?->getCode(), self::ERROR_REPORT_TYPE_CODES, true))) {
            return $this->response(false, [
                'data' => ['error' => 'notfound'],
            ]);
        }

        return $this->response(true, [
            'template' => 'worksheets/add/index_main.html.twig',
            'templateData' => [
                'item' => $item,
                'isNew' => $isNew,
                'worksheetTypes' => $worksheetTypes,
                'partners' => $partnerRepository->findBy([], ['name' => 'ASC']),
                'machines' => $machineRepository->findBy([], ['title' => 'ASC']),
            ],
            'data' => [
                'options' => [
                    'save_enabled' => $isNew || (int) $item->getStatus() > 0,
                ],
                'worksheet' => $this->serializeWorksheet($item),
                'attachments' => $isNew ? [] : array_map(function (WorksheetAttachment $attachment): array {
                    return $this->serializeAttachment($attachment);
                }, $worksheetAttachmentRepository->findBy(['worksheet' => $item], ['id' => 'DESC'])),
            ],
        ]);
    }

    #[Route('/worksheets/attachments-list-index', name: 'index_worksheet_attachments_list', methods: ['POST'])]
    public function index_worksheet_attachments_list(
        Request $request,
    ): Response
    {
        return $this->response(true, [
            'template' => 'worksheets/add/index_worksheet_attachments_list.html.twig',
            'templateData' => [
                'worksheet_id' => $request->request->get('worksheet_id', ''),
            ],
            'data' => [],
        ]);
    }

    #[Route('/worksheets/attachments-list', name: 'list_worksheet_attachments_list', methods: ['GET', 'POST'])]
    public function list_worksheet_attachments_list(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetAttachmentRepository $worksheetAttachmentRepository,
        UserRepository $userRepository,
    ): Response
    {
        $worksheetIdRaw = $request->request->get('worksheet_id', $request->query->get('worksheet_id', ''));
        $worksheetId = is_numeric($worksheetIdRaw) ? (int) $worksheetIdRaw : 0;
        $worksheet = $worksheetId > 0 ? $worksheetRepository->find($worksheetId) : null;
        $attachments = $worksheet ? $worksheetAttachmentRepository->findBy(['worksheet' => $worksheet], ['id' => 'DESC']) : [];
        $filtersJson = $request->request->get('filters', $request->query->get('filters', '{}'));
        $filters = json_decode($filtersJson, true);
        $search = is_array($filters) ? trim((string) ($filters['search'] ?? '')) : '';

        if ($search !== '') {
            $attachments = array_values(array_filter($attachments, static function (WorksheetAttachment $attachment) use ($search): bool {
                return stripos($attachment->getName() ?? '', $search) !== false
                    || stripos($attachment->getDescription() ?? '', $search) !== false;
            }));
        }

        $userIds = [];
        foreach ($attachments as $attachment) {
            $userId = $attachment->getUidAdd() ?? $attachment->getUidLast();
            if ($userId !== null) {
                $userIds[] = $userId;
            }
        }

        $usersById = [];
        if ($userIds !== []) {
            foreach ($userRepository->findBy(['id' => array_values(array_unique($userIds))]) as $user) {
                $usersById[$user->getId()] = $user->getName() ?: $user->getUserName();
            }
        }

        return $this->response(true, [
            'template' => 'worksheets/add/list_worksheet_attachments_list.html.twig',
            'templateData' => [
                'worksheet_id' => $worksheetId,
                'attachments' => array_map(function (WorksheetAttachment $attachment) use ($usersById): array {
                    $userId = $attachment->getUidAdd() ?? $attachment->getUidLast();

                    return $this->buildAttachmentCard($attachment, $userId !== null ? ($usersById[$userId] ?? null) : null);
                }, $attachments),
            ],
            'data' => [],
        ]);
    }

    #[Route('/get/attachment', name: 'getdata_attachment', methods: ['GET'])]
    public function getdata_attachment(
        Request $request,
        WorksheetAttachmentRepository $worksheetAttachmentRepository,
    ): Response {
        $id = $request->query->getInt('id');
        $attachment = $id > 0 ? $worksheetAttachmentRepository->find($id) : null;

        if (!$attachment) {
            return new Response('Attachment not found.', Response::HTTP_NOT_FOUND);
        }

        $filePath = $this->resolveAttachmentPath($attachment->getData() ?? []);
        if ($filePath === null) {
            return new Response('Attachment file not found.', Response::HTTP_NOT_FOUND);
        }

        $mimeType = mime_content_type($filePath) ?: 'application/octet-stream';
        $fileName = $attachment->getName() ?: basename($filePath);
        $fallbackFileName = preg_replace('/[^A-Za-z0-9._-]+/', '-', $fileName) ?: 'attachment';
        $disposition = $request->query->getBoolean('download')
            ? ResponseHeaderBag::DISPOSITION_ATTACHMENT
            : ResponseHeaderBag::DISPOSITION_INLINE;

        $response = new BinaryFileResponse($filePath);
        $response->headers->set('Content-Type', $mimeType);
        $response->setContentDisposition($disposition, $fileName, $fallbackFileName);

        return $response;
    }

    #[Route('/worksheets/signatures/add', name: 'index_worksheet_signature_add')]
    public function index_worksheet_signature_add(): Response
    {
        return $this->response(true, [
            'template' => 'worksheets/add/index_worksheet_signature_add.html.twig'
        ], 'json');

    }

    #[Route('/worksheets/save', name: 'save_worksheets', methods: ['POST'])]
    public function saveWorksheets(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetTypeRepository $worksheetTypeRepository,
        PartnerRepository $partnerRepository
    ): Response
    {
        $payload = json_decode((string) $request->request->get('data', ''), true);
        if (!is_array($payload) || !is_array($payload['worksheet'] ?? null)) {
            return $this->response(false, [
                'data' => ['error' => 'Érvénytelen munkalap adatok.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $worksheetInput = $payload['worksheet'];
        $rawId = $worksheetInput['id'] ?? null;
        $isNew = $rawId === null || $rawId === '';

        if (!$isNew && !is_numeric($rawId)) {
            return $this->response(false, [
                'data' => ['error' => 'Érvénytelen munkalap azonosító.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $worksheet = $isNew ? new Worksheet() : $worksheetRepository->find((int) $rawId);
        if (!$worksheet) {
            return $this->response(false, [
                'data' => ['error' => 'A munkalap nem található.'],
            ], 'json', Response::HTTP_NOT_FOUND);
        }

        $worksheetTypeId = $worksheetInput['worksheet_type_id'] ?? $worksheetInput['worksheet_type'] ?? null;
        $worksheetType = is_numeric($worksheetTypeId)
            ? $worksheetTypeRepository->find((int) $worksheetTypeId)
            : null;

        if (!$worksheetType) {
            return $this->response(false, [
                'data' => ['error' => 'Válassz munkalap típust.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $title = trim((string) ($worksheetInput['title'] ?? $worksheetInput['worksheet_title'] ?? ''));
        if ($title === '') {
            return $this->response(false, [
                'data' => ['error' => 'Add meg a munkalap címét.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $partnerId = $worksheetInput['partner_id'] ?? null;
        $partner = null;
        if ($partnerId !== null && $partnerId !== '') {
            $partner = is_numeric($partnerId) ? $partnerRepository->find((int) $partnerId) : null;
            if (!$partner) {
                return $this->response(false, [
                    'data' => ['error' => 'A kiválasztott partner nem található.'],
                ], 'json', Response::HTTP_BAD_REQUEST);
            }
        }

        $worksheetData = $worksheetInput['data'] ?? [];
        if (!is_array($worksheetData)) {
            return $this->response(false, [
                'data' => ['error' => 'A munkalap JSON data mezője érvénytelen.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        if (array_key_exists('machine_id', $worksheetInput)) {
            $worksheetData['machine_id'] = $worksheetInput['machine_id'];
        }
        if (is_array($payload['contacts'] ?? null) && $payload['contacts'] !== []) {
            $worksheetData['contacts'] = $payload['contacts'];
        }
        $worksheetData['worksheet_type_code'] = $worksheetType->getCode();

        $status = (string) ($worksheetInput['status'] ?? ($worksheet->getStatus() ?: '1'));
        $allowedStatuses = in_array($worksheetType->getCode(), self::ERROR_REPORT_TYPE_CODES, true)
            ? ['1', '2', '-1', '-2']
            : ['1', '0'];
        if (!in_array($status, $allowedStatuses, true)) {
            return $this->response(false, [
                'data' => ['error' => 'Érvénytelen munkalap státusz.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $now = new \DateTimeImmutable();
        if ($isNew) {
            $worksheet
                ->setCode($this->generateWorksheetCode($worksheetRepository))
                ->setDatetimeAdd($now)
                ->setDatetimeOpen($now)
                ->setUidAdd($this->getUser()?->getId());
        }

        $worksheet
            ->setTitle($title)
            ->setWorksheetType($worksheetType)
            ->setPartner($partner)
            ->setData($worksheetData)
            ->setStatus($status)
            ->setDatetimeLast($now)
            ->setDatetimeClosed((int) $status <= 0 ? ($worksheet->getDatetimeClosed() ?? $now) : null)
            ->setUidLast($this->getUser()?->getId());

        $worksheetRepository->save($worksheet);

        return $this->response(true, [
            'data' => [
                'worksheet_id' => $worksheet->getId(),
                'worksheet' => $this->serializeWorksheet($worksheet),
            ]
        ], 'json');
    }

    #[Route('/worksheets/attachments/save', name: 'save_worksheets_attachment', methods: ['POST'])]
    public function saveWorksheetsAttachment(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetAttachmentRepository $worksheetAttachmentRepository
    ): Response
    {
        $worksheetId = $request->request->get('worksheet_id');
        $worksheet = is_numeric($worksheetId) ? $worksheetRepository->find((int) $worksheetId) : null;
        if (!$worksheet) {
            return $this->response(false, [
                'data' => ['error' => 'A munkalap nem található.'],
            ], 'json', Response::HTTP_NOT_FOUND);
        }

        $operation = strtolower(trim((string) $request->request->get('function', '')));
        if (!in_array($operation, ['add', 'update', 'delete'], true)) {
            return $this->response(false, [
                'data' => ['error' => 'Érvénytelen csatolmány művelet.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $attachmentInput = json_decode((string) $request->request->get('data', '{}'), true);
        if (!is_array($attachmentInput)) {
            return $this->response(false, [
                'data' => ['error' => 'Érvénytelen csatolmány adatok.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $rawAttachmentId = $request->request->get('id');
        $attachment = null;
        if ($operation !== 'add') {
            $attachment = is_numeric($rawAttachmentId)
                ? $worksheetAttachmentRepository->find((int) $rawAttachmentId)
                : null;

            if (!$attachment || $attachment->getWorksheet()?->getId() !== $worksheet->getId()) {
                return $this->response(false, [
                    'data' => ['error' => 'A csatolmány nem található.'],
                ], 'json', Response::HTTP_NOT_FOUND);
            }
        }

        if ($operation === 'delete') {
            $filePath = $this->resolveAttachmentPath($attachment->getData() ?? []);
            if ($filePath !== null && is_file($filePath) && !unlink($filePath)) {
                return $this->response(false, [
                    'data' => ['error' => 'A csatolmány fájlja nem törölhető.'],
                ], 'json', Response::HTTP_INTERNAL_SERVER_ERROR);
            }

            $worksheetAttachmentRepository->delete($attachment);

            return $this->response(true, [
                'data' => ['id' => (int) $rawAttachmentId, 'deleted' => true],
            ], 'json');
        }

        $file = $request->files->get('file');
        if ($operation === 'add' && (!$file instanceof UploadedFile || !$file->isValid())) {
            return $this->response(false, [
                'data' => ['error' => 'A feltöltendő fájl hiányzik vagy hibás.'],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $clientData = $attachmentInput['data'] ?? [];
        $clientData = is_array($clientData) ? $clientData : [];
        unset($clientData['function'], $clientData['percentage'], $clientData['path'], $clientData['filename']);

        $oldFilePath = $attachment ? $this->resolveAttachmentPath($attachment->getData() ?? []) : null;
        $storedFile = null;
        if ($file instanceof UploadedFile && $file->isValid()) {
            try {
                $storedFile = $this->storeWorksheetAttachmentFile($file, (string) $worksheet->getCode());
            } catch (\RuntimeException $exception) {
                return $this->response(false, [
                    'data' => ['error' => $exception->getMessage()],
                ], 'json', Response::HTTP_BAD_REQUEST);
            }
        }

        $now = new \DateTimeImmutable();
        if ($operation === 'add') {
            $attachment = (new WorksheetAttachment())
                ->setWorksheet($worksheet)
                ->setDatetimeAdd($now)
                ->setDatetimeOpen($now)
                ->setUidAdd($this->getUser()?->getId())
                ->setStatus('1');
        }

        $recordData = array_replace($attachment->getData() ?? [], $clientData);
        if ($storedFile !== null) {
            $recordData = array_replace($recordData, [
                'filename' => $storedFile['fileName'],
                'size' => $storedFile['size'],
                'path' => $storedFile['path'],
                'type' => (string) ($file->getClientMimeType() ?? ''),
            ]);
        }

        $name = trim((string) ($attachmentInput['name'] ?? ''));
        if ($name === '') {
            $name = $storedFile['originalName'] ?? $attachment->getName() ?? 'csatolmány';
        }

        $description = trim((string) ($attachmentInput['description'] ?? ''));
        $attachment
            ->setName($name)
            ->setDescription($description !== '' ? $description : null)
            ->setData($recordData)
            ->setDatetimeLast($now)
            ->setUidLast($this->getUser()?->getId());

        $worksheetAttachmentRepository->save($attachment);

        if ($storedFile !== null && $oldFilePath !== null && is_file($oldFilePath)) {
            @unlink($oldFilePath);
        }

        return $this->response(true, [
            'data' => [
                'worksheet_id' => $worksheet->getId(),
                'attachment' => $this->serializeAttachment($attachment),
            ]
        ], 'json');
    }

    #[Route('/worksheets/list', name: 'list_worksheets', methods: ['GET', 'POST'])]
    public function listWorksheets(Request $request, WorksheetRepository $worksheetRepository): Response
    {
        $filtersJson = $request->request->get('filters', '{}');
        $filters = json_decode($filtersJson, true);

        if (!is_array($filters)) {
            return $this->response(false, [
                'data' => [
                    'error' => 'Invalid filters JSON.',
                ],
            ], 'json', Response::HTTP_BAD_REQUEST);
        }

        $isServiceOnly = $this->isGranted('ROLE_SERVICE')
            && !$this->isGranted('ROLE_MASTER')
            && !$this->isGranted('ROLE_PROJECTMANAGER');

        if ($isServiceOnly) {
            unset($filters['worksheet_type_id'], $filters['worksheet_type']);
            $filters['allowed_worksheet_type_codes'] = self::ERROR_REPORT_TYPE_CODES;
        }

        $pageRaw = $request->request->get('page', $request->query->get('page', 1));
        $page = is_numeric($pageRaw) ? (int) $pageRaw : 1;
        $list = $worksheetRepository->findList($filters, $page, self::ITEMS_PER_PAGE);

        foreach ($list['records'] as $index => $record) {
            $status = (int) $record['status'];
            $isErrorReport = in_array($record['worksheet_type_code'], self::ERROR_REPORT_TYPE_CODES, true);

            $list['records'][$index]['status_code'] = match (true) {
                $status <= 0 => 'closed',
                $isErrorReport && $status === 2 => 'inprogress',
                default => 'open',
            };
        }

        $content = $this->renderView('worksheets/list_worksheets.html.twig', [
            'records' => $list['records'],
            'filters' => $filters,
            'page' => $list['page'],
            'totalPages' => $list['totalPages'],
            'totalRecords' => $list['totalRecords'],
            'itemsPerPage' => $list['itemsPerPage'],
        ]);

        return $this->response(true, [
            'content' => $content,
            'data' => [
                'filters' => $filters,
                'page' => $list['page'],
                'totalPages' => $list['totalPages'],
                'totalRecords' => $list['totalRecords'],
                'itemsPerPage' => $list['itemsPerPage'],
            ],
        ]);
    }

    private function serializeWorksheet(Worksheet $worksheet): array
    {
        return [
            'id' => $worksheet->getId(),
            'title' => $worksheet->getTitle(),
            'code' => $worksheet->getCode(),
            'worksheet_type_id' => $worksheet->getWorksheetType()?->getId(),
            'partner_id' => $worksheet->getPartner()?->getId(),
            'rental_id' => $worksheet->getMachineRental()?->getId(),
            'data' => $worksheet->getData() ?? [],
            'status' => $worksheet->getStatus(),
            'datetime_add' => $worksheet->getDatetimeAdd()?->format('Y-m-d H:i:s'),
            'datetime_last' => $worksheet->getDatetimeLast()?->format('Y-m-d H:i:s'),
            'datetime_open' => $worksheet->getDatetimeOpen()?->format('Y-m-d H:i:s'),
            'datetime_closed' => $worksheet->getDatetimeClosed()?->format('Y-m-d H:i:s'),
            'temp_data' => [
                'worksheet_type_code' => $worksheet->getWorksheetType()?->getCode(),
            ]
        ];
    }

    private function serializeAttachment(WorksheetAttachment $attachment): array
    {
        return [
            'id' => $attachment->getId(),
            'name' => $attachment->getName(),
            'description' => $attachment->getDescription(),
            'data' => $attachment->getData() ?? [],
            'status' => $attachment->getStatus(),
            'datetime_add' => $attachment->getDatetimeAdd()?->format('Y-m-d H:i:s'),
            'datetime_last' => $attachment->getDatetimeLast()?->format('Y-m-d H:i:s'),
        ];
    }

    private function buildAttachmentCard(WorksheetAttachment $attachment, ?string $uploaderName = null): array
    {
        $data = $attachment->getData() ?? [];
        $filePath = $this->resolveAttachmentPath($data);
        $mimeType = $filePath ? (mime_content_type($filePath) ?: 'application/octet-stream') : 'application/octet-stream';
        $size = (int) ($data['size'] ?? ($filePath ? (filesize($filePath) ?: 0) : 0));

        return [
            'id' => $attachment->getId(),
            'name' => $attachment->getName(),
            'description' => $attachment->getDescription(),
            'size_label' => $this->formatFileSize($size),
            'datetime_add' => $attachment->getDatetimeAdd(),
            'is_image' => str_starts_with($mimeType, 'image/'),
            'mime_type' => $mimeType,
            'uploader_name' => $uploaderName,
            'url' => $this->generateUrl('getdata_attachment', ['id' => $attachment->getId()]),
            'download_url' => $this->generateUrl('getdata_attachment', [
                'id' => $attachment->getId(),
                'download' => 1,
            ]),
        ];
    }

    private function storeWorksheetAttachmentFile(UploadedFile $file, string $code): array
    {
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $code)) {
            throw new \RuntimeException('Érvénytelen munkalap kód.');
        }

        $uploadDir = $this->getParameter('kernel.project_dir') . '/uploads/worksheets/' . $code;
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
            throw new \RuntimeException('Nem sikerült létrehozni a feltöltési mappát.');
        }

        $originalName = $file->getClientOriginalName();
        $fileSize = $file->getSize() ?? 0;
        $safeName = preg_replace('/[^A-Za-z0-9._-]+/', '-', $originalName) ?: 'attachment';
        $fileName = uniqid('', true) . '-' . $safeName;

        $file->move($uploadDir, $fileName);

        return [
            'originalName' => $originalName,
            'fileName' => $fileName,
            'size' => $fileSize,
            'path' => '/uploads/worksheets/' . $code . '/' . $fileName,
        ];
    }

    private function resolveAttachmentPath(array $data): ?string
    {
        $relativePath = trim((string) ($data['path'] ?? ''));
        if ($relativePath === '') {
            return null;
        }

        $projectDir = (string) $this->getParameter('kernel.project_dir');
        $normalizedRelativePath = ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath), DIRECTORY_SEPARATOR);
        $filePath = realpath($projectDir . DIRECTORY_SEPARATOR . $normalizedRelativePath);

        if ($filePath === false) {
            return null;
        }

        $normalizedFilePath = strtolower($filePath);
        $allowedRoots = [
            realpath($projectDir . DIRECTORY_SEPARATOR . 'uploads'),
        ];

        foreach ($allowedRoots as $allowedRoot) {
            if ($allowedRoot === false) {
                continue;
            }

            $normalizedRoot = strtolower($allowedRoot);
            if ($normalizedFilePath === $normalizedRoot || str_starts_with($normalizedFilePath, $normalizedRoot . DIRECTORY_SEPARATOR)) {
                return $filePath;
            }
        }

        return null;
    }

    private function generateWorksheetCode(WorksheetRepository $worksheetRepository): string
    {
        do {
            $code = 'M' . date('Ym') . '-' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
        } while ($worksheetRepository->findOneBy(['code' => $code]) !== null);

        return $code;
    }

    private function formatFileSize(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return round($bytes / 1048576, 1) . ' MB';
        }

        if ($bytes >= 1024) {
            return round($bytes / 1024, 1) . ' KB';
        }

        return $bytes . ' B';
    }


    #[Route('/worksheets/pdf/{id}', name: 'index_worksheet_pdf', methods: ['GET'], defaults: ['id' => null])]
    public function index_worksheet_pdf(
        Request $request,
        WorksheetRepository $worksheetRepository,
        WorksheetAttachmentRepository $worksheetAttachmentRepository,
        ?string $id = null,
    ): Response {
        $identifier = trim((string) ($id ?? $request->query->get('id', '')));
        $worksheet = null;

        if ($identifier !== '') {
            $worksheet = is_numeric($identifier)
                ? $worksheetRepository->find((int) $identifier)
                : $worksheetRepository->findOneBy(['code' => $identifier]);
        }

        if (!$worksheet) {
            return new Response('Worksheet not found.', Response::HTTP_NOT_FOUND);
        }

        $html = $this->renderView('worksheets/pdf/index.html.twig', [
            'item' => $worksheet,
            'data' => $worksheet->getData() ?? [],
            'signatures' => $this->normalizePdfSignatures($worksheet->getData()['signatures'] ?? []),
            'image_attachments' => $this->buildPdfImageAttachments(
                $worksheetAttachmentRepository->findBy(['worksheet' => $worksheet], ['id' => 'ASC'])
            ),
        ]);

        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isRemoteEnabled', false);
        $options->set('isHtml5ParserEnabled', true);

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $fileName = preg_replace('/[^A-Za-z0-9._-]+/', '-', $worksheet->getCode() ?: ('worksheet-' . $worksheet->getId())) . '.pdf';

        return new Response($dompdf->output(), Response::HTTP_OK, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => sprintf('inline; filename="%s"', $fileName),
        ]);
    }

    private function normalizePdfSignatures(mixed $signatures): array
    {
        if (is_string($signatures)) {
            $decoded = json_decode($signatures, true);
            $signatures = is_array($decoded) ? $decoded : ['handed' => ['image' => $signatures]];
        }

        if (!is_array($signatures)) {
            $signatures = [];
        }

        foreach (['handed', 'received'] as $type) {
            $signature = $signatures[$type] ?? [];

            if (is_string($signature)) {
                $signature = [
                    'name' => '',
                    'image' => $signature,
                ];
            }

            if (!is_array($signature)) {
                $signature = [];
            }

            $image = trim((string) ($signature['image'] ?? $signature['base64'] ?? $signature['data'] ?? ''));
            if ($image !== '' && !str_starts_with($image, 'data:image/')) {
                $image = 'data:image/png;base64,' . $image;
            }

            $signatures[$type] = [
                'name' => trim((string) ($signature['name'] ?? '')),
                'image' => $image,
            ];
        }

        return $signatures;
    }

    /**
     * @param WorksheetAttachment[] $attachments
     */
    private function buildPdfImageAttachments(array $attachments): array
    {
        $items = [];

        foreach ($attachments as $attachment) {
            $path = $this->resolveAttachmentPath($attachment->getData() ?? []);
            if ($path === null || !is_file($path)) {
                continue;
            }

            $mimeType = mime_content_type($path) ?: 'application/octet-stream';
            if (!str_starts_with($mimeType, 'image/')) {
                continue;
            }

            $content = file_get_contents($path);
            if ($content === false) {
                continue;
            }

            $items[] = [
                'name' => $attachment->getName() ?: basename($path),
                'src' => sprintf('data:%s;base64,%s', $mimeType, base64_encode($content)),
            ];
        }

        return $items;
    }
}

<?php

namespace App\Controller;

use App\Entity\CompareMachinesQuote;
use App\Repository\CompareMachinesQuoteRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class CompareMachinesQuoteController extends AbstractController
{
    #[Route('/compare-machines/quote', name: 'compare_machines_quote_save', methods: ['POST'])]
    public function save(Request $request, CompareMachinesQuoteRepository $quoteRepository): JsonResponse
    {
        $data = [
            'name' => trim((string) $request->request->get('name', '')),
            'company' => trim((string) $request->request->get('company', '')),
            'email' => trim((string) $request->request->get('email', '')),
            'phone' => trim((string) $request->request->get('phone', '')),
            'machine_pair' => trim((string) $request->request->get('machine_pair', '')),
            'months' => trim((string) $request->request->get('months', '')),
            'message' => trim((string) $request->request->get('message', '')),
        ];

        $errors = [];
        if ($data['name'] === '') {
            $errors[] = 'Név megadása kötelező.';
        }
        if ($data['company'] === '') {
            $errors[] = 'Cégnév megadása kötelező.';
        }
        if ($data['email'] === '') {
            $errors[] = 'E-mail megadása kötelező.';
        } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Érvényes e-mail címet adjon meg.';
        }
        if ($data['phone'] === '') {
            $errors[] = 'Telefonszám megadása kötelező.';
        }
        if ($data['machine_pair'] === '') {
            $errors[] = 'Kiválasztott modell-pár megadása kötelező.';
        }
        if ($data['months'] === '' || !is_numeric($data['months']) || (int) $data['months'] < 1) {
            $errors[] = 'Munkaidő hónapban megadása kötelező.';
        }
        if ($data['message'] === '') {
            $errors[] = 'Üzenet megadása kötelező.';
        }

        if ($errors !== []) {
            return $this->json([
                'success' => false,
                'message' => 'Kérem javítsa az alábbi adatokat:<br>' . implode('<br>', $errors),
                'errors' => $errors,
            ], Response::HTTP_BAD_REQUEST);
        }

        $code = $this->generateQuoteCode();
        $quote = (new CompareMachinesQuote())
            ->setTitle('Darupár ajánlatkérés: ' . $data['name'])
            ->setCode($code)
            ->setData([
                'Név' => $data['name'],
                'Cégnév' => $data['company'],
                'E-mail' => $data['email'],
                'Telefonszám' => $data['phone'],
                'Kiválasztott modell-pár' => $data['machine_pair'],
                'Munkaidő hónapban' => (int) $data['months'],
                'Üzenet' => $data['message'],
            ]);

        $quoteRepository->save($quote);

        return $this->json([
            'success' => true,
            'message' => 'Az árajánlattal kapcsolatban kollégáink hamarosan felveszik Önnel a kapcsolatot.',
            'code' => $code,
            'id' => $quote->getId(),
        ]);
    }

    private function generateQuoteCode(): string
    {
        return 'AJ' . date('Ym') . '-' . random_int(10000000, 99999999);
    }
}

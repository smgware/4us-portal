<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260804140000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add description to worksheet attachments.';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('worksheet_attachment') && !$schema->getTable('worksheet_attachment')->hasColumn('description')) {
            $this->addSql('ALTER TABLE worksheet_attachment ADD description VARCHAR(255) DEFAULT NULL');
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('worksheet_attachment') && $schema->getTable('worksheet_attachment')->hasColumn('description')) {
            $this->addSql('ALTER TABLE worksheet_attachment DROP description');
        }
    }
}

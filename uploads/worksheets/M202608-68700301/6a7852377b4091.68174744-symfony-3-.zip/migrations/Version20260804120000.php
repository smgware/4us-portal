<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260804120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Rename partner contact note to description.';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('partner_contact') || !$schema->getTable('partner_contact')->hasColumn('note')) {
            return;
        }

        $this->addSql('ALTER TABLE partner_contact CHANGE note description LONGTEXT DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        if (!$schema->hasTable('partner_contact') || !$schema->getTable('partner_contact')->hasColumn('description')) {
            return;
        }

        $this->addSql('ALTER TABLE partner_contact CHANGE description note LONGTEXT DEFAULT NULL');
    }
}

<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260803140000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create partner contacts table.';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('partner_contact')) {
            return;
        }

        $this->addSql('CREATE TABLE partner_contact (id INT AUTO_INCREMENT NOT NULL, partner_id INT NOT NULL, name VARCHAR(255) NOT NULL, title VARCHAR(255) DEFAULT NULL, email VARCHAR(255) DEFAULT NULL, phone VARCHAR(80) DEFAULT NULL, note LONGTEXT DEFAULT NULL, datetime_add DATETIME DEFAULT NULL, datetime_last DATETIME DEFAULT NULL, uid_add INT DEFAULT NULL, uid_last INT DEFAULT NULL, INDEX IDX_8B8885259393F8FE (partner_id), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('ALTER TABLE partner_contact ADD CONSTRAINT FK_8B8885259393F8FE FOREIGN KEY (partner_id) REFERENCES partner (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('partner_contact')) {
            $this->addSql('DROP TABLE partner_contact');
        }
    }
}

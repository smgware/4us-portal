<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20260701160708 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE machine_rental (id INT AUTO_INCREMENT NOT NULL, code VARCHAR(255) NOT NULL, datetime_rental_start DATETIME DEFAULT NULL, datetime_rental_end DATETIME DEFAULT NULL, status VARCHAR(255) NOT NULL, uid_add INT DEFAULT NULL, uid_last INT DEFAULT NULL, datetime_add DATETIME DEFAULT NULL, datetime_last DATETIME DEFAULT NULL, partner_id INT NOT NULL, machine_id INT NOT NULL, INDEX IDX_DF3C6D389393F8FE (partner_id), INDEX IDX_DF3C6D38F6B75B26 (machine_id), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('ALTER TABLE machine_rental ADD CONSTRAINT FK_DF3C6D389393F8FE FOREIGN KEY (partner_id) REFERENCES partner (id)');
        $this->addSql('ALTER TABLE machine_rental ADD CONSTRAINT FK_DF3C6D38F6B75B26 FOREIGN KEY (machine_id) REFERENCES machine (id)');
        $this->addSql('ALTER TABLE user CHANGE status status VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE worksheet ADD partner_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE worksheet ADD CONSTRAINT FK_23DA50C19393F8FE FOREIGN KEY (partner_id) REFERENCES partner (id) ON DELETE SET NULL');
        $this->addSql('CREATE INDEX IDX_23DA50C19393F8FE ON worksheet (partner_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE machine_rental DROP FOREIGN KEY FK_DF3C6D389393F8FE');
        $this->addSql('ALTER TABLE machine_rental DROP FOREIGN KEY FK_DF3C6D38F6B75B26');
        $this->addSql('DROP TABLE machine_rental');
        $this->addSql('ALTER TABLE `user` CHANGE status status VARCHAR(255) DEFAULT \'1\' NOT NULL');
        $this->addSql('ALTER TABLE worksheet DROP FOREIGN KEY FK_23DA50C19393F8FE');
        $this->addSql('DROP INDEX IDX_23DA50C19393F8FE ON worksheet');
        $this->addSql('ALTER TABLE worksheet DROP partner_id');
    }
}

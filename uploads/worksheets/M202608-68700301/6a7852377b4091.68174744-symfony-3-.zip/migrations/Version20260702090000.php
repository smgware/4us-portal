<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260702090000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add rental relation to worksheet records.';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE worksheet ADD rental_id INT DEFAULT NULL');
        $this->addSql('CREATE INDEX IDX_23DA50C1A7CF2329 ON worksheet (rental_id)');
        $this->addSql('ALTER TABLE worksheet ADD CONSTRAINT FK_WORKSHEET_RENTAL_ID FOREIGN KEY (rental_id) REFERENCES machine_rental (id) ON DELETE SET NULL');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE worksheet DROP FOREIGN KEY FK_WORKSHEET_RENTAL_ID');
        $this->addSql('DROP INDEX IDX_23DA50C1A7CF2329 ON worksheet');
        $this->addSql('ALTER TABLE worksheet DROP rental_id');
    }
}

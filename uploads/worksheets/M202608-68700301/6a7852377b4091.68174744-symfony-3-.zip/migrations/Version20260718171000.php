<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260718171000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create compare machines quote table.';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE compare_machines_quote (id INT AUTO_INCREMENT NOT NULL, title VARCHAR(255) NOT NULL, code VARCHAR(32) NOT NULL, data JSON DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE compare_machines_quote');
    }
}

<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260702143000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add user permission assignments table.';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE user_permission (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, permission_id INT NOT NULL, uid_add INT DEFAULT NULL, uid_last INT DEFAULT NULL, datetime_add DATETIME DEFAULT NULL, datetime_last DATETIME DEFAULT NULL, INDEX IDX_472E5446A76ED395 (user_id), INDEX IDX_472E5446FED90CCA (permission_id), UNIQUE INDEX UNIQ_USER_PERMISSION_USER_PERMISSION (user_id, permission_id), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('ALTER TABLE user_permission ADD CONSTRAINT FK_USER_PERMISSION_USER_ID FOREIGN KEY (user_id) REFERENCES `user` (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE user_permission ADD CONSTRAINT FK_USER_PERMISSION_PERMISSION_ID FOREIGN KEY (permission_id) REFERENCES permission (id) ON DELETE CASCADE');
        $this->addSql('INSERT IGNORE INTO user_permission (user_id, permission_id, datetime_add, datetime_last) SELECT id, permission_id, NOW(), NOW() FROM `user` WHERE permission_id IS NOT NULL');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE user_permission DROP FOREIGN KEY FK_USER_PERMISSION_USER_ID');
        $this->addSql('ALTER TABLE user_permission DROP FOREIGN KEY FK_USER_PERMISSION_PERMISSION_ID');
        $this->addSql('DROP TABLE user_permission');
    }
}

<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260804130000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add default contact flag and remove legacy partner contact columns.';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('partner_contact') && !$schema->getTable('partner_contact')->hasColumn('default_contact')) {
            $this->addSql('ALTER TABLE partner_contact ADD default_contact TINYINT(1) DEFAULT 0 NOT NULL');
        }

        if ($schema->hasTable('partner')) {
            $table = $schema->getTable('partner');
            foreach (['contact_name', 'contact_phone', 'contact_email'] as $column) {
                if ($table->hasColumn($column)) {
                    $this->addSql(sprintf('ALTER TABLE partner DROP COLUMN %s', $column));
                }
            }
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('partner_contact') && $schema->getTable('partner_contact')->hasColumn('default_contact')) {
            $this->addSql('ALTER TABLE partner_contact DROP default_contact');
        }

        if ($schema->hasTable('partner')) {
            $table = $schema->getTable('partner');
            if (!$table->hasColumn('contact_name')) {
                $this->addSql('ALTER TABLE partner ADD contact_name VARCHAR(255) DEFAULT NULL');
            }
            if (!$table->hasColumn('contact_phone')) {
                $this->addSql('ALTER TABLE partner ADD contact_phone VARCHAR(80) DEFAULT NULL');
            }
            if (!$table->hasColumn('contact_email')) {
                $this->addSql('ALTER TABLE partner ADD contact_email VARCHAR(255) DEFAULT NULL');
            }
        }
    }
}

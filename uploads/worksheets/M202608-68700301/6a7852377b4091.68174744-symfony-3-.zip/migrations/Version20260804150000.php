<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260804150000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Make partner tax number unique.';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('partner')) {
            $this->addSql('CREATE UNIQUE INDEX UNIQ_312B3E16DA4A75FF ON partner (tax_number)');
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('partner')) {
            $this->addSql('DROP INDEX UNIQ_312B3E16DA4A75FF ON partner');
        }
    }
}
